﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phil_s_Name_Changer
{
    //Have user enter their challonge API key
    //Either TOs to control tournament, or theirs to just grab info from tournament
    //


    //icon ideas:
    // [ ]
    // LBL
    // NC
    
    //ALL TXT FILES
    //============================
    //title, title2
    //set1, set2
    //player1Cam, player2Cam
    //player1Screen, player2Screen

    //BEHAVIOURS
    //====================================================
    //Sets are changed immediately after incrementation
    //Names are only changed after hitting 'Apply'
    //Name positions are only changed after hitting 'Apply'

    public partial class Form1 : Form
    {
        private string currentpCam1 = "[Top]";
        private string currentcCam1 = "[Top]";
        private string currentpCam2 = "[Bottom]";
        private string currentcCam2 = "[Bottom]";
        private string currentpScreen1 = "[Left]";
        private string currentcScreen1 = "[Left]";
        private string currentpScreen2 = "[Right]";
        private string currentcScreen2 = "[Right]";
        

        public Form1()
        {
            InitializeComponent();
            //Sets default values for player name positions upon running
            lblPos1.Text = currentpCam1 + " " + currentpScreen1;
            lblPos2.Text = currentpCam2 + " " + currentpScreen2;
            //Sets default values for commentator name positions upon running
            lblCom1.Text = currentcCam1 + " " + currentcScreen1;
            lblCom2.Text = currentcCam2 + " " + currentcScreen2;
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam1.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam2.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen1.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen2.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam1.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam2.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen1.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen2.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter1.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter2.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch1.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch2.txt"))
            {
                //
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("challonge.txt"))
            {
                //
            }
        }

        private void txtPlay1_TextChanged(object sender, EventArgs e)
        {
            btnApplyNames.Text = "Apply*"; //Apply button changes to Apply*
        }

        
        private void txtPlay2_TextChanged(object sender, EventArgs e)
        {
            btnApplyNames.Text = "Apply*"; //Apply button changes to Apply*
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            //Resets: nmSet1, nmSet2 (Current value changes to 0)
            //Applies once clicked
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //btnSwapCam
            //Swaps camera labels (top, bottom)
            //Reset by: btnResetPlayers
            //Applies: btnApplyAll
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //btnResetPlayers
            //Resets txtPlay1 txtPlay2 to blank
            //Resets [Cam, Screen] labels to default [Top, Left], [Bottom, Right]
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void profileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("title.txt"))
            {
                writetext.WriteLine(txtTitle.Text);
            }
        }

        private void txtSubTitle_TextChanged(object sender, EventArgs e)
        {
            //Modifies: "title" text file, for recording setup it will be meetup #
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("subtitle.txt"))
            {
                writetext.WriteLine(txtSub.Text);
            }
        }

        private void nmSet1_ValueChanged(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set1.txt"))
            {
                writetext.WriteLine(nmSet1.Value);
            }
            //Modifies: set1 text file
            //0=1, 1=0, 2=1, 3=2

            //Reset by: btnResetSet
            //Applies: Once incremented
        }

        private void nmSet2_ValueChanged(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set2.txt"))
            {
                writetext.WriteLine(nmSet2.Value);
            }
            //Modify: set2 text file
            //Reset by: btnResetSet
            //Applies: Once incremented
        }

        private void btnResetSet_Click(object sender, EventArgs e)
        {
            //Change nmSet1 and nmSet2 to 0
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set1.txt"))
            {
                writetext.WriteLine("0");
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set2.txt"))
            {
                writetext.WriteLine("0");
            }

            nmSet1.Value = 0;
            nmSet2.Value = 0;

        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            //btnApplyNames
            //Apply based on position
            //If currentCam1Pos = [Top] or [Bottom]

            if (currentpCam1 == "[Top]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam1.txt"))
                {
                    writetext.WriteLine(txtPlay1.Text);
                }
            }
            else if (currentpCam1 == "[Bottom]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam2.txt"))
                {
                    writetext.WriteLine(txtPlay1.Text);
                }
            }

            if (currentpCam2 == "[Top]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam1.txt"))
                {
                    writetext.WriteLine(txtPlay2.Text);
                }
            }
            else if (currentpCam2 == "[Bottom]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam2.txt"))
                {
                    writetext.WriteLine(txtPlay2.Text);
                }
            }



            if (currentpScreen1 == "[Left]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen1.txt"))
                {
                    writetext.WriteLine(txtPlay1.Text);
                }
            }
            else if (currentpScreen1 == "[Right]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen2.txt"))
                {
                    writetext.WriteLine(txtPlay1.Text);
                }
            }

            if (currentpScreen2 == "[Left]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen1.txt"))
                {
                    writetext.WriteLine(txtPlay2.Text);
                }
            }
            else if (currentpScreen2 == "[Right]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen2.txt"))
                {
                    writetext.WriteLine(txtPlay2.Text);
                }
            }

            btnApplyNames.Text = "Apply";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnSwapCam_Click(object sender, EventArgs e)
        {
            string temp1 = "";
            string temp2 = "";
            string lbltemp1 = "";
            string lbltemp2 = "";

            //Swap values Value1-> Temp1, Value2-> Temp2, Value1 = Temp2, Value2 = Temp1
            //Read, set temp
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("pCam1.txt"))
            {
                temp1 = readtext.ReadLine();
            }
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("pCam2.txt"))
            {
                temp2 = readtext.ReadLine();
            }

            //Write temp into files
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam1.txt"))
            {
                writetext.WriteLine(temp2);
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam2.txt"))
            {
                writetext.WriteLine(temp1);
            }

            //Swap labels
            lbltemp1 = currentpCam1;
            lbltemp2 = currentpCam2;

            currentpCam1 = lbltemp2;
            currentpCam2 = lbltemp1;

            lblPos1.Text = currentpCam1 + " " + currentpScreen1;
            lblPos2.Text = currentpCam2 + " " + currentpScreen2;
        }

        private void btnSwapScreen_Click(object sender, EventArgs e)
        {
            string temp1 = "";
            string temp2 = "";
            string set1Temp = "";
            string set2Temp = "";
            string lbltemp1 = "";
            string lbltemp2 = "";

            //=====Players=====
            //Swap values Value1-> Temp1, Value2-> Temp2, Value1 = Temp2, Value2 = Temp1
            //Read, set temp
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("pScreen1.txt"))
            {
                temp1 = readtext.ReadLine();
            }
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("pScreen2.txt"))
            {
                temp2 = readtext.ReadLine();
            }
            //Write temp into files
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen1.txt"))
            {
                writetext.WriteLine(temp2);
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen2.txt"))
            {
                writetext.WriteLine(temp1);
            }

            //=====SET=====
            //Swap values Value1-> Temp1, Value2-> Temp2, Value1 = Temp2, Value2 = Temp1
            //Swapping set values
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("set1.txt"))
            {
                set1Temp = readtext.ReadLine();
            }
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("set2.txt"))
            {
                set2Temp = readtext.ReadLine();
            }
            //Writing into set files 
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set1.txt"))
            {
                writetext.WriteLine(set2Temp);
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set2.txt"))
            {
                writetext.WriteLine(set1Temp);
            }
            
            //Swap player labels 
            lbltemp1 = currentpScreen1;
            lbltemp2 = currentpScreen2;
            currentpScreen1 = lbltemp2;
            currentpScreen2 = lbltemp1;
            
            //Swap set labels/values
            nmSet1.Value = Convert.ToDecimal(set2Temp);
            nmSet2.Value = Convert.ToDecimal(set1Temp);

            lblPos1.Text = currentpCam1 + " " + currentpScreen1;
            lblPos2.Text = currentpCam2 + " " + currentpScreen2;
        }

        private void btnResetPlayers_Click(object sender, EventArgs e)
        {
            //Setting default cam+screen positions
            currentpCam1 = "[Top]";
            currentpCam2 = "[Bottom]";
            currentpScreen1 = "[Left]";
            currentpScreen2 = "[Right]";
            lblPos1.Text = currentpCam1 + " " + currentpScreen1;
            lblPos2.Text = currentpCam2 + " " + currentpScreen2;

            //Clear text boxes
            txtPlay1.Text = "";
            txtPlay2.Text = "";

            //Clear files
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam1.txt"))
            { }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam2.txt"))
            { }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen1.txt"))
            { }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen2.txt"))
            { }

            if (nmSet1.Value != 0)
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set1.txt"))
                { }
                nmSet1.Value = 0;
                
            }

            if (nmSet2.Value != 0)
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set2.txt"))
                { }
                nmSet2.Value = 0;
            }

            btnApplyNames.Text = "Apply";
        }

        private void lblPlayers_Click(object sender, EventArgs e)
        {

        }

        private void boxStock1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDashboardLink_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.twitch.tv/dashboard");
        }

        private void btnChallongeLink_Click(object sender, EventArgs e)
        {
            String link = "";
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("challonge.txt"))
            {
                link = readtext.ReadLine();
            }
            System.Diagnostics.Process.Start(link);
        }

        private void txtCom1_TextChanged(object sender, EventArgs e)
        {
            btnApplyComs.Text = "Apply*";
        }

        private void txtCom2_TextChanged(object sender, EventArgs e)
        {
            btnApplyComs.Text = "Apply*";
        }

        private void txtTwitter1_TextChanged(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter1.txt"))
            {
                writetext.WriteLine(txtTwitter1.Text);
            }
        }

        private void txtTwitter2_TextChanged(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter2.txt"))
            {
                writetext.WriteLine(txtTwitter2.Text);
            }
        }

        private void txtTwitch1_TextChanged(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch1.txt"))
            {
                writetext.WriteLine(txtTwitch1.Text);
            }
        }

        private void txtTwitch2_TextChanged(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch2.txt"))
            {
                writetext.WriteLine(txtTwitch2.Text);
            }
        }

        //COPY COM1 AND COM2 TO RESPECTIVE SOCIAL MEDIA FIELDS
        private void btnCopyComs_Click(object sender, EventArgs e)
        {

            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter1.txt"))
            {
                writetext.WriteLine("@" + txtCom1.Text);
            }
            txtTwitter1.Text = "@" + txtCom1.Text;

            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter2.txt"))
            {
                writetext.WriteLine("@" + txtCom2.Text);
            }
            txtTwitter2.Text = "@" + txtCom2.Text;

            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch1.txt"))
            {
                writetext.WriteLine("/" + txtCom1.Text);
            }
            txtTwitch1.Text = "/" + txtCom1.Text;

            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch2.txt"))
            {
                writetext.WriteLine("/" + txtCom2.Text);
            }
            txtTwitch2.Text = "/" + txtCom2.Text;
        }

        private void btnApplyComs_Click(object sender, EventArgs e)
        {
            if (currentcCam1 == "[Top]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam1.txt"))
                {
                    writetext.WriteLine(txtCom1.Text);
                }
            }
            else if (currentcCam1 == "[Bottom]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam2.txt"))
                {
                    writetext.WriteLine(txtCom1.Text);
                }
            }

            if (currentcCam2 == "[Top]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam1.txt"))
                {
                    writetext.WriteLine(txtCom2.Text);
                }
            }
            else if (currentcCam2 == "[Bottom]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam2.txt"))
                {
                    writetext.WriteLine(txtCom2.Text);
                }
            }



            if (currentcScreen1 == "[Left]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen1.txt"))
                {
                    writetext.WriteLine(txtCom1.Text);
                }
            }
            else if (currentcScreen1 == "[Right]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen2.txt"))
                {
                    writetext.WriteLine(txtCom1.Text);
                }
            }

            if (currentcScreen2 == "[Left]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen1.txt"))
                {
                    writetext.WriteLine(txtCom2.Text);
                }
            }
            else if (currentcScreen2 == "[Right]")
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen2.txt"))
                {
                    writetext.WriteLine(txtCom2.Text);
                }
            }
            btnApplyComs.Text = "Apply";
        }

        private void btnResetComs_Click(object sender, EventArgs e)
        {
            //Setting default cam+screen positions
            currentcCam1 = "[Top]";
            currentcCam2 = "[Bottom]";
            currentcScreen1 = "[Left]";
            currentcScreen2 = "[Right]";
            lblCom1.Text = currentcCam1 + " " + currentcScreen1;
            lblCom2.Text = currentcCam2 + " " + currentcScreen2;

            //Clear text boxes
            txtCom1.Text = "";
            txtCom2.Text = "";
            txtTwitch1.Text = "/";
            txtTwitch2.Text = "/";
            txtTwitter1.Text = "@";
            txtTwitter2.Text = "@";

            //Clear files
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam1.txt"))
            {}
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam2.txt"))
            {}
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen1.txt"))
            {}
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen2.txt"))
            {}

            //Reset twitter and twitch
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter1.txt"))
            {}
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter2.txt"))
            {}
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch1.txt"))
            {}
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch2.txt"))
            {}

            btnApplyComs.Text = "Apply";
        }

        private void btnSwapComScreen_Click(object sender, EventArgs e)
        {
            string temp1 = "";
            string temp2 = "";
            string lbltemp1 = "";
            string lbltemp2 = "";

            //Swap values Value1-> Temp1, Value2-> Temp2, Value1 = Temp2, Value2 = Temp1
            //Read, set temp
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("cScreen1.txt"))
            {
                temp1 = readtext.ReadLine();
            }
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("cScreen2.txt"))
            {
                temp2 = readtext.ReadLine();
            }

            //Write temp into files
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen1.txt"))
            {
                writetext.WriteLine(temp2);
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen2.txt"))
            {
                writetext.WriteLine(temp1);
            }

            //Swap twitter and twitch
            string temp3 = "";
            string temp4 = "";
            string temp5 = "";
            string temp6 = "";

            using (System.IO.StreamReader readtext = new System.IO.StreamReader("cTwitter1.txt"))
            {
                temp3 = readtext.ReadLine();
            }
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("cTwitter2.txt"))
            {
                temp4 = readtext.ReadLine();
            }

            //Write temp into files
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter1.txt"))
            {
                writetext.WriteLine(temp4);
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter2.txt"))
            {
                writetext.WriteLine(temp3);
            }

            //Read twitch into temps
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("cTwitch1.txt"))
            {
                temp5 = readtext.ReadLine();
            }
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("cTwitch2.txt"))
            {
                temp6 = readtext.ReadLine();
            }

            //Write temps into opposite twitch
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch1.txt"))
            {
                writetext.WriteLine(temp6);
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch2.txt"))
            {
                writetext.WriteLine(temp5);
            }

            //Swap comm labels
            lbltemp1 = currentcScreen1;
            lbltemp2 = currentcScreen2;

            currentcScreen1 = lbltemp2;
            currentcScreen2 = lbltemp1;

            lblCom1.Text = currentcCam1 + " " + currentcScreen1;
            lblCom2.Text = currentcCam2 + " " + currentcScreen2;
            
        }

        private void btnSwapComCam_Click(object sender, EventArgs e)
        {
            string temp1 = "";
            string temp2 = "";
            string lbltemp1 = "";
            string lbltemp2 = "";

            //Swap values Value1-> Temp1, Value2-> Temp2, Value1 = Temp2, Value2 = Temp1
            //Read, set temp
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("cCam1.txt"))
            {
                temp1 = readtext.ReadLine();
            }
            using (System.IO.StreamReader readtext = new System.IO.StreamReader("cCam2.txt"))
            {
                temp2 = readtext.ReadLine();
            }

            //Write temp into files
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam1.txt"))
            {
                writetext.WriteLine(temp2);
            }
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam2.txt"))
            {
                writetext.WriteLine(temp1);
            }

            //Swap comm labels
            lbltemp1 = currentcCam1;
            lbltemp2 = currentcCam2;

            currentcCam1 = lbltemp2;
            currentcCam2 = lbltemp1;

            lblCom1.Text = currentcCam1 + " " + currentcScreen1;
            lblCom2.Text = currentcCam2 + " " + currentcScreen2;
        }

        private void btnResetAll_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("               Everything will be reset.", "Are you sure?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                //==================
                //RESET PLAYER BOXES
                //==================
                //Setting default cam+screen positions
                currentpCam1 = "[Top]";
                currentpCam2 = "[Bottom]";
                currentpScreen1 = "[Left]";
                currentpScreen2 = "[Right]";
                lblPos1.Text = currentpCam1 + " " + currentpScreen1;
                lblPos2.Text = currentpCam2 + " " + currentpScreen2;

                //Clear text boxes
                txtPlay1.Text = "";
                txtPlay2.Text = "";

                //Clear files
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam2.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen2.txt"))
                { }
                //Reset set count with this button as well

                btnApplyNames.Text = "Apply";


                //=======================
                //RESET COMMENTATOR BOXES
                //=======================
                //Setting default cam+screen positions
                currentcCam1 = "[Top]";
                currentcCam2 = "[Bottom]";
                currentcScreen1 = "[Left]";
                currentcScreen2 = "[Right]";
                lblCom1.Text = currentcCam1 + " " + currentcScreen1;
                lblCom2.Text = currentcCam2 + " " + currentcScreen2;

                //Clear text boxes
                txtCom1.Text = "";
                txtCom2.Text = "";
                txtTwitch1.Text = "/";
                txtTwitch2.Text = "/";
                txtTwitter1.Text = "@";
                txtTwitter2.Text = "@";

                //Clear files
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cCam2.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cScreen2.txt"))
                { }

                //Reset twitter and twitch
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitter2.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("cTwitch2.txt"))
                { }

                btnApplyComs.Text = "Apply";

                //RESET TITLE
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("title.txt"))
                { }
                txtTitle.Text = "";

                //RESET SUB-TITLE
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("subtitle.txt"))
                { }
                txtSub.Text = "";
            }
            else if (dialogResult == DialogResult.No)
            {
                ///If no, do nothing
            }
        }

        private void btnRecordMatch_Click(object sender, EventArgs e)
        {
            //Prompt: Please verify the information is correct
            //Yes: "Info is correct" 
            //No: "Lemme change"

            DialogResult dialogResult = MessageBox.Show("\tFields will be reset.", "Are you sure?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("matches.txt", true))
                {
                    //Player1 Score Character
                    writetext.Write(txtPlay1.Text + " ");
                    writetext.Write(nmSet1.Value + " ");
                    writetext.WriteLine(boxStock1.Text);

                    //Player2 Score Character
                    writetext.Write(txtPlay2.Text + " ");
                    writetext.Write(nmSet2.Value + " ");
                    writetext.WriteLine(boxStock1.Text + "\n");
                }

                //
                //RESET ALL PLAYER BOXES
                //
                currentpCam1 = "[Top]";
                currentpCam2 = "[Bottom]";
                currentpScreen1 = "[Left]";
                currentpScreen2 = "[Right]";
                lblPos1.Text = currentpCam1 + " " + currentpScreen1;
                lblPos2.Text = currentpCam2 + " " + currentpScreen2;

                //Clear text boxes
                txtPlay1.Text = "";
                txtPlay2.Text = "";

                //Clear files
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pCam2.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("pScreen2.txt"))
                { }

                //Reset set count
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set1.txt"))
                { }
                using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("set2.txt"))
                { }
                nmSet1.Value = 0;
                nmSet2.Value = 0;

                btnApplyNames.Text = "Apply";
            }
            else if (dialogResult == DialogResult.No)
            {
                ///If no, do nothing
            }
        }

        private void lblURL_Click(object sender, EventArgs e)
        {

        }

        private void txtChallongeURL_TextChanged(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter writetext = new System.IO.StreamWriter("challonge.txt"))
            {
                writetext.WriteLine("" + txtChallongeURL.Text);
            }
            //Print to challonge file, bracket button links to whatever url is put into here. API fetched/manipulated on this URL as well
        }
    }
}

public class Methods
{
    //Swap methods
    public void swapContents(String fileName1, String fileName2)
    {
        
    }

    public void swapValues(String value1, String value2)
    {
        //Parameters are strings, because strings can be whatever, and changed into anything
    }
    //Reset method
    //Should this technically just invoke the constructor?
    public void toDefault()
    { }
}