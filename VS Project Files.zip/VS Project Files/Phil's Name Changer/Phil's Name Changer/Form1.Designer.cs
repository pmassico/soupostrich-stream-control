﻿namespace Phil_s_Name_Changer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabRecording = new System.Windows.Forms.TabPage();
            this.txtChallongeURL = new System.Windows.Forms.TextBox();
            this.lblChallongeURL = new System.Windows.Forms.Label();
            this.btnResetAll = new System.Windows.Forms.Button();
            this.btnChallongeLink = new System.Windows.Forms.Button();
            this.btnDashboardLink = new System.Windows.Forms.Button();
            this.btnRecordMatch = new System.Windows.Forms.Button();
            this.txtSub = new System.Windows.Forms.TextBox();
            this.lblSub = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblComs = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTwitch2 = new System.Windows.Forms.TextBox();
            this.lblCom1 = new System.Windows.Forms.Label();
            this.txtTwitch1 = new System.Windows.Forms.TextBox();
            this.lblCom2 = new System.Windows.Forms.Label();
            this.txtTwitter1 = new System.Windows.Forms.TextBox();
            this.txtTwitter2 = new System.Windows.Forms.TextBox();
            this.btnSwapComCam = new System.Windows.Forms.Button();
            this.btnResetComs = new System.Windows.Forms.Button();
            this.btnApplyComs = new System.Windows.Forms.Button();
            this.btnSwapComScreen = new System.Windows.Forms.Button();
            this.btnCopyComs = new System.Windows.Forms.Button();
            this.txtCom1 = new System.Windows.Forms.TextBox();
            this.txtCom2 = new System.Windows.Forms.TextBox();
            this.boxPlayers = new System.Windows.Forms.GroupBox();
            this.btnReportMatch = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCharIcon = new System.Windows.Forms.Label();
            this.lblPos1 = new System.Windows.Forms.Label();
            this.lblPos2 = new System.Windows.Forms.Label();
            this.boxStock2 = new System.Windows.Forms.ComboBox();
            this.btnSwapCam = new System.Windows.Forms.Button();
            this.lblPlayers = new System.Windows.Forms.Label();
            this.boxStock1 = new System.Windows.Forms.ComboBox();
            this.nmSet1 = new System.Windows.Forms.NumericUpDown();
            this.nmSet2 = new System.Windows.Forms.NumericUpDown();
            this.btnResetPlayers = new System.Windows.Forms.Button();
            this.btnApplyNames = new System.Windows.Forms.Button();
            this.txtPlay2 = new System.Windows.Forms.TextBox();
            this.btnSwapScreen = new System.Windows.Forms.Button();
            this.txtPlay1 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabRecording.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.boxPlayers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabRecording);
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(701, 347);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabRecording
            // 
            this.tabRecording.Controls.Add(this.txtChallongeURL);
            this.tabRecording.Controls.Add(this.lblChallongeURL);
            this.tabRecording.Controls.Add(this.btnResetAll);
            this.tabRecording.Controls.Add(this.btnChallongeLink);
            this.tabRecording.Controls.Add(this.btnDashboardLink);
            this.tabRecording.Controls.Add(this.btnRecordMatch);
            this.tabRecording.Controls.Add(this.txtSub);
            this.tabRecording.Controls.Add(this.lblSub);
            this.tabRecording.Controls.Add(this.lblTitle);
            this.tabRecording.Controls.Add(this.txtTitle);
            this.tabRecording.Controls.Add(this.groupBox1);
            this.tabRecording.Controls.Add(this.boxPlayers);
            this.tabRecording.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabRecording.Location = new System.Drawing.Point(4, 22);
            this.tabRecording.Name = "tabRecording";
            this.tabRecording.Padding = new System.Windows.Forms.Padding(3);
            this.tabRecording.Size = new System.Drawing.Size(693, 321);
            this.tabRecording.TabIndex = 0;
            this.tabRecording.Text = "Streaming";
            this.tabRecording.UseVisualStyleBackColor = true;
            // 
            // txtChallongeURL
            // 
            this.txtChallongeURL.Location = new System.Drawing.Point(85, 84);
            this.txtChallongeURL.Name = "txtChallongeURL";
            this.txtChallongeURL.Size = new System.Drawing.Size(117, 20);
            this.txtChallongeURL.TabIndex = 96;
            this.txtChallongeURL.TextChanged += new System.EventHandler(this.txtChallongeURL_TextChanged);
            // 
            // lblChallongeURL
            // 
            this.lblChallongeURL.AutoSize = true;
            this.lblChallongeURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChallongeURL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblChallongeURL.Location = new System.Drawing.Point(6, 87);
            this.lblChallongeURL.Name = "lblChallongeURL";
            this.lblChallongeURL.Size = new System.Drawing.Size(81, 13);
            this.lblChallongeURL.TabIndex = 95;
            this.lblChallongeURL.Text = "challonge.com/";
            this.lblChallongeURL.Click += new System.EventHandler(this.lblURL_Click);
            // 
            // btnResetAll
            // 
            this.btnResetAll.Location = new System.Drawing.Point(9, 289);
            this.btnResetAll.Name = "btnResetAll";
            this.btnResetAll.Size = new System.Drawing.Size(192, 23);
            this.btnResetAll.TabIndex = 94;
            this.btnResetAll.Text = "RESET ALL";
            this.btnResetAll.UseVisualStyleBackColor = true;
            this.btnResetAll.Click += new System.EventHandler(this.btnResetAll_Click);
            // 
            // btnChallongeLink
            // 
            this.btnChallongeLink.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnChallongeLink.Location = new System.Drawing.Point(115, 229);
            this.btnChallongeLink.Name = "btnChallongeLink";
            this.btnChallongeLink.Size = new System.Drawing.Size(86, 23);
            this.btnChallongeLink.TabIndex = 93;
            this.btnChallongeLink.Text = "Challonge";
            this.btnChallongeLink.UseVisualStyleBackColor = true;
            this.btnChallongeLink.Click += new System.EventHandler(this.btnChallongeLink_Click);
            // 
            // btnDashboardLink
            // 
            this.btnDashboardLink.ForeColor = System.Drawing.Color.Purple;
            this.btnDashboardLink.Location = new System.Drawing.Point(9, 229);
            this.btnDashboardLink.Name = "btnDashboardLink";
            this.btnDashboardLink.Size = new System.Drawing.Size(87, 23);
            this.btnDashboardLink.TabIndex = 91;
            this.btnDashboardLink.Text = "Dashboard";
            this.btnDashboardLink.UseVisualStyleBackColor = true;
            this.btnDashboardLink.Click += new System.EventHandler(this.btnDashboardLink_Click);
            // 
            // btnRecordMatch
            // 
            this.btnRecordMatch.Location = new System.Drawing.Point(9, 260);
            this.btnRecordMatch.Name = "btnRecordMatch";
            this.btnRecordMatch.Size = new System.Drawing.Size(192, 23);
            this.btnRecordMatch.TabIndex = 88;
            this.btnRecordMatch.Text = "Record Match To File";
            this.btnRecordMatch.UseVisualStyleBackColor = true;
            this.btnRecordMatch.Click += new System.EventHandler(this.btnRecordMatch_Click);
            // 
            // txtSub
            // 
            this.txtSub.Location = new System.Drawing.Point(85, 47);
            this.txtSub.Name = "txtSub";
            this.txtSub.Size = new System.Drawing.Size(117, 20);
            this.txtSub.TabIndex = 34;
            this.txtSub.TextChanged += new System.EventHandler(this.txtSubTitle_TextChanged);
            // 
            // lblSub
            // 
            this.lblSub.AutoSize = true;
            this.lblSub.Location = new System.Drawing.Point(6, 51);
            this.lblSub.Name = "lblSub";
            this.lblSub.Size = new System.Drawing.Size(49, 13);
            this.lblSub.TabIndex = 33;
            this.lblSub.Text = "Sub-Title";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(6, 18);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(27, 13);
            this.lblTitle.TabIndex = 23;
            this.lblTitle.Text = "Title";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(85, 13);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(117, 20);
            this.txtTitle.TabIndex = 22;
            this.txtTitle.TextChanged += new System.EventHandler(this.txtTitle_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblComs);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtTwitch2);
            this.groupBox1.Controls.Add(this.lblCom1);
            this.groupBox1.Controls.Add(this.txtTwitch1);
            this.groupBox1.Controls.Add(this.lblCom2);
            this.groupBox1.Controls.Add(this.txtTwitter1);
            this.groupBox1.Controls.Add(this.txtTwitter2);
            this.groupBox1.Controls.Add(this.btnSwapComCam);
            this.groupBox1.Controls.Add(this.btnResetComs);
            this.groupBox1.Controls.Add(this.btnApplyComs);
            this.groupBox1.Controls.Add(this.btnSwapComScreen);
            this.groupBox1.Controls.Add(this.btnCopyComs);
            this.groupBox1.Controls.Add(this.txtCom1);
            this.groupBox1.Controls.Add(this.txtCom2);
            this.groupBox1.Location = new System.Drawing.Point(211, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(477, 156);
            this.groupBox1.TabIndex = 89;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Commentators";
            // 
            // lblComs
            // 
            this.lblComs.AutoSize = true;
            this.lblComs.Location = new System.Drawing.Point(11, 17);
            this.lblComs.Name = "lblComs";
            this.lblComs.Size = new System.Drawing.Size(83, 13);
            this.lblComs.TabIndex = 70;
            this.lblComs.Text = "[Cam]   [Screen]";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(219, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 82;
            this.label2.Text = "Twitter";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(348, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 83;
            this.label1.Text = "Twitch";
            // 
            // txtTwitch2
            // 
            this.txtTwitch2.Location = new System.Drawing.Point(352, 67);
            this.txtTwitch2.Name = "txtTwitch2";
            this.txtTwitch2.Size = new System.Drawing.Size(113, 20);
            this.txtTwitch2.TabIndex = 87;
            this.txtTwitch2.Text = "/";
            this.txtTwitch2.TextChanged += new System.EventHandler(this.txtTwitch2_TextChanged);
            // 
            // lblCom1
            // 
            this.lblCom1.AutoSize = true;
            this.lblCom1.Location = new System.Drawing.Point(11, 41);
            this.lblCom1.Name = "lblCom1";
            this.lblCom1.Size = new System.Drawing.Size(77, 13);
            this.lblCom1.TabIndex = 71;
            this.lblCom1.Text = "[Cam] [Screen]";
            // 
            // txtTwitch1
            // 
            this.txtTwitch1.Location = new System.Drawing.Point(352, 38);
            this.txtTwitch1.Name = "txtTwitch1";
            this.txtTwitch1.Size = new System.Drawing.Size(113, 20);
            this.txtTwitch1.TabIndex = 86;
            this.txtTwitch1.Text = "/";
            this.txtTwitch1.TextChanged += new System.EventHandler(this.txtTwitch1_TextChanged);
            // 
            // lblCom2
            // 
            this.lblCom2.AutoSize = true;
            this.lblCom2.Location = new System.Drawing.Point(11, 70);
            this.lblCom2.Name = "lblCom2";
            this.lblCom2.Size = new System.Drawing.Size(77, 13);
            this.lblCom2.TabIndex = 72;
            this.lblCom2.Text = "[Cam] [Screen]";
            // 
            // txtTwitter1
            // 
            this.txtTwitter1.Location = new System.Drawing.Point(223, 38);
            this.txtTwitter1.Name = "txtTwitter1";
            this.txtTwitter1.Size = new System.Drawing.Size(111, 20);
            this.txtTwitter1.TabIndex = 84;
            this.txtTwitter1.Text = "@";
            this.txtTwitter1.TextChanged += new System.EventHandler(this.txtTwitter1_TextChanged);
            // 
            // txtTwitter2
            // 
            this.txtTwitter2.Location = new System.Drawing.Point(223, 67);
            this.txtTwitter2.Name = "txtTwitter2";
            this.txtTwitter2.Size = new System.Drawing.Size(111, 20);
            this.txtTwitter2.TabIndex = 85;
            this.txtTwitter2.Text = "@";
            this.txtTwitter2.TextChanged += new System.EventHandler(this.txtTwitter2_TextChanged);
            // 
            // btnSwapComCam
            // 
            this.btnSwapComCam.Location = new System.Drawing.Point(14, 96);
            this.btnSwapComCam.Name = "btnSwapComCam";
            this.btnSwapComCam.Size = new System.Drawing.Size(94, 23);
            this.btnSwapComCam.TabIndex = 80;
            this.btnSwapComCam.Text = "Swap Cam";
            this.btnSwapComCam.UseVisualStyleBackColor = true;
            this.btnSwapComCam.Click += new System.EventHandler(this.btnSwapComCam_Click);
            // 
            // btnResetComs
            // 
            this.btnResetComs.Location = new System.Drawing.Point(14, 125);
            this.btnResetComs.Name = "btnResetComs";
            this.btnResetComs.Size = new System.Drawing.Size(94, 23);
            this.btnResetComs.TabIndex = 76;
            this.btnResetComs.Text = "Reset";
            this.btnResetComs.UseVisualStyleBackColor = true;
            this.btnResetComs.Click += new System.EventHandler(this.btnResetComs_Click);
            // 
            // btnApplyComs
            // 
            this.btnApplyComs.Location = new System.Drawing.Point(112, 125);
            this.btnApplyComs.Name = "btnApplyComs";
            this.btnApplyComs.Size = new System.Drawing.Size(94, 23);
            this.btnApplyComs.TabIndex = 77;
            this.btnApplyComs.Text = "Apply";
            this.btnApplyComs.UseVisualStyleBackColor = true;
            this.btnApplyComs.Click += new System.EventHandler(this.btnApplyComs_Click);
            // 
            // btnSwapComScreen
            // 
            this.btnSwapComScreen.Location = new System.Drawing.Point(112, 96);
            this.btnSwapComScreen.Name = "btnSwapComScreen";
            this.btnSwapComScreen.Size = new System.Drawing.Size(94, 23);
            this.btnSwapComScreen.TabIndex = 81;
            this.btnSwapComScreen.Text = "Swap Screen";
            this.btnSwapComScreen.UseVisualStyleBackColor = true;
            this.btnSwapComScreen.Click += new System.EventHandler(this.btnSwapComScreen_Click);
            // 
            // btnCopyComs
            // 
            this.btnCopyComs.Location = new System.Drawing.Point(94, 12);
            this.btnCopyComs.Name = "btnCopyComs";
            this.btnCopyComs.Size = new System.Drawing.Size(111, 21);
            this.btnCopyComs.TabIndex = 75;
            this.btnCopyComs.Text = "Copy To All";
            this.btnCopyComs.UseVisualStyleBackColor = true;
            this.btnCopyComs.Click += new System.EventHandler(this.btnCopyComs_Click);
            // 
            // txtCom1
            // 
            this.txtCom1.Location = new System.Drawing.Point(94, 38);
            this.txtCom1.Name = "txtCom1";
            this.txtCom1.Size = new System.Drawing.Size(111, 20);
            this.txtCom1.TabIndex = 73;
            this.txtCom1.TextChanged += new System.EventHandler(this.txtCom1_TextChanged);
            // 
            // txtCom2
            // 
            this.txtCom2.Location = new System.Drawing.Point(94, 67);
            this.txtCom2.Name = "txtCom2";
            this.txtCom2.Size = new System.Drawing.Size(111, 20);
            this.txtCom2.TabIndex = 74;
            this.txtCom2.TextChanged += new System.EventHandler(this.txtCom2_TextChanged);
            // 
            // boxPlayers
            // 
            this.boxPlayers.Controls.Add(this.btnReportMatch);
            this.boxPlayers.Controls.Add(this.label3);
            this.boxPlayers.Controls.Add(this.lblCharIcon);
            this.boxPlayers.Controls.Add(this.lblPos1);
            this.boxPlayers.Controls.Add(this.lblPos2);
            this.boxPlayers.Controls.Add(this.boxStock2);
            this.boxPlayers.Controls.Add(this.btnSwapCam);
            this.boxPlayers.Controls.Add(this.lblPlayers);
            this.boxPlayers.Controls.Add(this.boxStock1);
            this.boxPlayers.Controls.Add(this.nmSet1);
            this.boxPlayers.Controls.Add(this.nmSet2);
            this.boxPlayers.Controls.Add(this.btnResetPlayers);
            this.boxPlayers.Controls.Add(this.btnApplyNames);
            this.boxPlayers.Controls.Add(this.txtPlay2);
            this.boxPlayers.Controls.Add(this.btnSwapScreen);
            this.boxPlayers.Controls.Add(this.txtPlay1);
            this.boxPlayers.Location = new System.Drawing.Point(211, 169);
            this.boxPlayers.Name = "boxPlayers";
            this.boxPlayers.Size = new System.Drawing.Size(479, 149);
            this.boxPlayers.TabIndex = 92;
            this.boxPlayers.TabStop = false;
            this.boxPlayers.Text = "Players";
            // 
            // btnReportMatch
            // 
            this.btnReportMatch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnReportMatch.Location = new System.Drawing.Point(350, 92);
            this.btnReportMatch.Name = "btnReportMatch";
            this.btnReportMatch.Size = new System.Drawing.Size(109, 51);
            this.btnReportMatch.TabIndex = 97;
            this.btnReportMatch.Text = "Report match to challonge";
            this.btnReportMatch.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(348, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 96;
            this.label3.Text = "Set Count";
            // 
            // lblCharIcon
            // 
            this.lblCharIcon.AutoSize = true;
            this.lblCharIcon.Location = new System.Drawing.Point(219, 16);
            this.lblCharIcon.Name = "lblCharIcon";
            this.lblCharIcon.Size = new System.Drawing.Size(53, 13);
            this.lblCharIcon.TabIndex = 95;
            this.lblCharIcon.Text = "Char Icon";
            // 
            // lblPos1
            // 
            this.lblPos1.AutoSize = true;
            this.lblPos1.Location = new System.Drawing.Point(9, 37);
            this.lblPos1.Name = "lblPos1";
            this.lblPos1.Size = new System.Drawing.Size(59, 13);
            this.lblPos1.TabIndex = 19;
            this.lblPos1.Text = "[Top] [Left]";
            // 
            // lblPos2
            // 
            this.lblPos2.AutoSize = true;
            this.lblPos2.Location = new System.Drawing.Point(9, 66);
            this.lblPos2.Name = "lblPos2";
            this.lblPos2.Size = new System.Drawing.Size(80, 13);
            this.lblPos2.TabIndex = 20;
            this.lblPos2.Text = "[Bottom] [Right]";
            // 
            // boxStock2
            // 
            this.boxStock2.FormattingEnabled = true;
            this.boxStock2.Location = new System.Drawing.Point(222, 63);
            this.boxStock2.Name = "boxStock2";
            this.boxStock2.Size = new System.Drawing.Size(111, 21);
            this.boxStock2.TabIndex = 79;
            this.boxStock2.Text = "(stock_icon2)";
            // 
            // btnSwapCam
            // 
            this.btnSwapCam.Location = new System.Drawing.Point(12, 92);
            this.btnSwapCam.Name = "btnSwapCam";
            this.btnSwapCam.Size = new System.Drawing.Size(94, 23);
            this.btnSwapCam.TabIndex = 29;
            this.btnSwapCam.Text = "Swap Cam";
            this.btnSwapCam.UseVisualStyleBackColor = true;
            this.btnSwapCam.Click += new System.EventHandler(this.btnSwapCam_Click);
            // 
            // lblPlayers
            // 
            this.lblPlayers.AutoSize = true;
            this.lblPlayers.Location = new System.Drawing.Point(9, 16);
            this.lblPlayers.Name = "lblPlayers";
            this.lblPlayers.Size = new System.Drawing.Size(77, 13);
            this.lblPlayers.TabIndex = 28;
            this.lblPlayers.Text = "[Cam] [Screen]";
            // 
            // boxStock1
            // 
            this.boxStock1.FormattingEnabled = true;
            this.boxStock1.Location = new System.Drawing.Point(222, 34);
            this.boxStock1.Name = "boxStock1";
            this.boxStock1.Size = new System.Drawing.Size(111, 21);
            this.boxStock1.TabIndex = 78;
            this.boxStock1.Text = "(stock_icon1)";
            this.boxStock1.SelectedIndexChanged += new System.EventHandler(this.boxStock1_SelectedIndexChanged);
            // 
            // nmSet1
            // 
            this.nmSet1.Location = new System.Drawing.Point(350, 35);
            this.nmSet1.Name = "nmSet1";
            this.nmSet1.Size = new System.Drawing.Size(111, 20);
            this.nmSet1.TabIndex = 25;
            this.nmSet1.ValueChanged += new System.EventHandler(this.nmSet1_ValueChanged);
            // 
            // nmSet2
            // 
            this.nmSet2.Location = new System.Drawing.Point(350, 64);
            this.nmSet2.Name = "nmSet2";
            this.nmSet2.Size = new System.Drawing.Size(111, 20);
            this.nmSet2.TabIndex = 26;
            this.nmSet2.ValueChanged += new System.EventHandler(this.nmSet2_ValueChanged);
            // 
            // btnResetPlayers
            // 
            this.btnResetPlayers.Location = new System.Drawing.Point(12, 120);
            this.btnResetPlayers.Name = "btnResetPlayers";
            this.btnResetPlayers.Size = new System.Drawing.Size(94, 24);
            this.btnResetPlayers.TabIndex = 31;
            this.btnResetPlayers.Text = "Reset";
            this.btnResetPlayers.UseVisualStyleBackColor = true;
            this.btnResetPlayers.Click += new System.EventHandler(this.btnResetPlayers_Click);
            // 
            // btnApplyNames
            // 
            this.btnApplyNames.Location = new System.Drawing.Point(110, 121);
            this.btnApplyNames.Name = "btnApplyNames";
            this.btnApplyNames.Size = new System.Drawing.Size(94, 23);
            this.btnApplyNames.TabIndex = 32;
            this.btnApplyNames.Text = "Apply";
            this.btnApplyNames.UseVisualStyleBackColor = true;
            this.btnApplyNames.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // txtPlay2
            // 
            this.txtPlay2.Location = new System.Drawing.Point(93, 63);
            this.txtPlay2.Name = "txtPlay2";
            this.txtPlay2.Size = new System.Drawing.Size(111, 20);
            this.txtPlay2.TabIndex = 21;
            this.txtPlay2.TextChanged += new System.EventHandler(this.txtPlay2_TextChanged);
            // 
            // btnSwapScreen
            // 
            this.btnSwapScreen.Location = new System.Drawing.Point(110, 92);
            this.btnSwapScreen.Name = "btnSwapScreen";
            this.btnSwapScreen.Size = new System.Drawing.Size(94, 23);
            this.btnSwapScreen.TabIndex = 30;
            this.btnSwapScreen.Text = "Swap Screen";
            this.btnSwapScreen.UseVisualStyleBackColor = true;
            this.btnSwapScreen.Click += new System.EventHandler(this.btnSwapScreen_Click);
            // 
            // txtPlay1
            // 
            this.txtPlay1.Location = new System.Drawing.Point(93, 34);
            this.txtPlay1.Name = "txtPlay1";
            this.txtPlay1.Size = new System.Drawing.Size(111, 20);
            this.txtPlay1.TabIndex = 18;
            this.txtPlay1.TextChanged += new System.EventHandler(this.txtPlay1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 349);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "SOUPOSTRICH\'s Name Changer";
            this.tabControl1.ResumeLayout(false);
            this.tabRecording.ResumeLayout(false);
            this.tabRecording.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.boxPlayers.ResumeLayout(false);
            this.boxPlayers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmSet2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCom2;
        private System.Windows.Forms.TextBox txtCom1;
        private System.Windows.Forms.Button btnCopyComs;
        private System.Windows.Forms.Button btnSwapComScreen;
        private System.Windows.Forms.Button btnApplyComs;
        private System.Windows.Forms.Button btnResetComs;
        private System.Windows.Forms.Button btnSwapComCam;
        private System.Windows.Forms.TextBox txtTwitter2;
        private System.Windows.Forms.TextBox txtTwitter1;
        private System.Windows.Forms.Label lblCom2;
        private System.Windows.Forms.TextBox txtTwitch1;
        private System.Windows.Forms.Label lblCom1;
        private System.Windows.Forms.TextBox txtTwitch2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblComs;
        private System.Windows.Forms.TextBox txtPlay1;
        private System.Windows.Forms.Label lblPos1;
        private System.Windows.Forms.Label lblPos2;
        private System.Windows.Forms.TextBox txtPlay2;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.NumericUpDown nmSet1;
        private System.Windows.Forms.NumericUpDown nmSet2;
        private System.Windows.Forms.Label lblPlayers;
        private System.Windows.Forms.Button btnSwapCam;
        private System.Windows.Forms.Button btnSwapScreen;
        private System.Windows.Forms.Button btnResetPlayers;
        private System.Windows.Forms.Button btnApplyNames;
        private System.Windows.Forms.Label lblSub;
        private System.Windows.Forms.TextBox txtSub;
        private System.Windows.Forms.ComboBox boxStock1;
        private System.Windows.Forms.ComboBox boxStock2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabRecording;
        private System.Windows.Forms.Button btnChallongeLink;
        private System.Windows.Forms.Button btnDashboardLink;
        private System.Windows.Forms.Button btnRecordMatch;
        private System.Windows.Forms.GroupBox boxPlayers;
        private System.Windows.Forms.Button btnResetAll;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCharIcon;
        private System.Windows.Forms.TextBox txtChallongeURL;
        private System.Windows.Forms.Label lblChallongeURL;
        private System.Windows.Forms.Button btnReportMatch;
    }
}

